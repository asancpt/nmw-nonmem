InitStep = function(DataAll, THETAinit, OMinit, SGinit, nTheta, LB=rep(0, nTheta), UB=rep(0, nTheta), PredFile="PRED4.R", METHOD="ZERO")
{
  e$PRED <- source(PredFile)$value
  e$IDs <- unique(DataAll[,"ID"])
  e$nID <- length(e$IDs)
  e$Oi = matrix(nrow=e$nID, ncol=3)
  colnames(e$Oi) = c("ID", "OFVi", "nRec")

  e$DataRef = list()
  for (i in 1:e$nID) {
    DATAi = DataAll[DataAll[,"ID"]==e$IDs[i],]
    e$Oi[i, "ID"] = e$IDs[i]
    e$Oi[i, "nRec"] = dim(DATAi)[1]
    e$DataRef[[i]] = DATAi
  }

  e$nTheta <- nTheta
  e$nEta   <- dim(OMinit)[1]
  e$nEps   <- dim(SGinit)[1]
  e$nPara  <- e$nTheta + e$nEta*(e$nEta + 1)/2 + e$nEps  # Assume Full Block Omega

  e$GNames = vector()
  for (i in 1:e$nEta) e$GNames[i] = paste0("G",i)

  e$HNames = vector()
  for (i in 1:e$nEps) e$HNames[i] = paste0("H",i)

  e$DNames = vector()
  for (i in 1:e$nEta) for (j in 1:i) e$DNames = append(e$DNames, paste0("D",i,j))

  e$EtaNames = vector(length=e$nEta)
  for (i in 1:e$nEta) e$EtaNames[i] = paste0("ETA",i)

  e$EBE = cbind(e$IDs, matrix(rep(0, e$nID*e$nEta), nrow=e$nID, ncol=e$nEta))
  colnames(e$EBE) = c("ID", e$EtaNames)

  IE = THETAinit
  e$alpha  <- 0.1 - log(IE/(UB - LB)/(1 - IE/(UB - LB)))
  e$OMscl  <- ScaleVar(OMinit, e$nEta)
  e$SGscl  <- ScaleVar(SGinit, e$nEps)

  e$METHOD <- METHOD
  e$THETAinit <- THETAinit
  e$OMinit <- OMinit
  e$SGinit <- SGinit
  e$LB     <- LB
  e$UB     <- UB
  e$OMindex <- (e$nTheta + 1):(e$nTheta + e$nEta*(e$nEta + 1)/2)
  e$SGindex <- (e$nPara - e$nEps + 1):e$nPara
}

#require(Rvmmin)

EstStep = function()
{
  e$STEP <- "EST"
  OFVinit = Obj(rep(0.1, e$nPara))
  StartTime = Sys.time()
  Res = optim(rep(0.1, e$nPara), Obj, method="L-BFGS-B", hessian=TRUE)
  RunTime = difftime(Sys.time(), StartTime)
  e$FinalPara <- DECN(Res$par)
  Result = list(OFVinit, RunTime, Res, e$FinalPara)
  names(Result) = list("Initial OFV", "Time", "Optim", "Final Estimates")
  return(Result)
}

#require(numDeriv)

CovStep = function()
{
  e$STEP <- "COV"
  StartTime = Sys.time()
  Rmat = Hessian(Obj, e$FinalPara)/2  # FinalPara from EstStep()
  Smat = CalcSmat()
  invR = solve(Rmat)
  Cov = invR %*% Smat %*% invR
  SE = sqrt(diag(Cov))
  Correl = cov2cor(Cov)
#  InvCov = solve(Cov)
  InvCov = Rmat %*% solve(Smat) %*% Rmat
  EigenVal = sort(eigen(Correl)$values) # Sorted Eigenvalues

  RunTime = difftime(Sys.time(), StartTime)
  Result = list(RunTime, SE, Cov, Correl, InvCov, EigenVal, Rmat, Smat)
  names(Result) = list("Time", "Standard Error", "Covariance Matrix of Estimates", "Correlation Matrix of Estimates", "Inverse Covariance Matrix of Estimates", "Eigen Values", "R Matrix", "S Matrix")
  return(Result)
}

